/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "A:/School/ECE/ECE 431L/Lab3 temp sensor/Controller.v";
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {7U, 0U};
static unsigned int ng3[] = {11U, 0U};
static unsigned int ng4[] = {16U, 0U};
static unsigned int ng5[] = {17U, 0U};
static unsigned int ng6[] = {18U, 0U};
static unsigned int ng7[] = {0U, 0U};
static int ng8[] = {0, 0};
static unsigned int ng9[] = {2U, 0U};
static unsigned int ng10[] = {24U, 0U};
static unsigned int ng11[] = {3U, 0U};
static unsigned int ng12[] = {4U, 0U};
static unsigned int ng13[] = {5U, 0U};
static unsigned int ng14[] = {6U, 0U};
static int ng15[] = {1, 0};
static unsigned int ng16[] = {8U, 0U};
static int ng17[] = {15, 0};
static int ng18[] = {8, 0};
static unsigned int ng19[] = {9U, 0U};
static int ng20[] = {7, 0};
static unsigned int ng21[] = {10U, 0U};
static int ng22[] = {256, 0};
static unsigned int ng23[] = {12U, 0U};
static unsigned int ng24[] = {13U, 0U};
static int ng25[] = {99, 0};
static int ng26[] = {100, 0};
static unsigned int ng27[] = {14U, 0U};
static int ng28[] = {9, 0};
static int ng29[] = {10, 0};
static unsigned int ng30[] = {15U, 0U};



static void Cont_53_0(char *t0)
{
    char t6[8];
    char t22[8];
    char t39[8];
    char t55[8];
    char t63[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    char *t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    unsigned int t96;
    unsigned int t97;
    char *t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    unsigned int t102;
    unsigned int t103;
    char *t104;

LAB0:    t1 = (t0 + 8400U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 6840);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t22, 0, 8);
    t23 = (t6 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t6);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t23) != 0)
        goto LAB10;

LAB11:    t30 = (t22 + 4);
    t31 = *((unsigned int *)t22);
    t32 = (!(t31));
    t33 = *((unsigned int *)t30);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB12;

LAB13:    memcpy(t63, t22, 8);

LAB14:    t91 = (t0 + 9328);
    t92 = (t91 + 56U);
    t93 = *((char **)t92);
    t94 = (t93 + 56U);
    t95 = *((char **)t94);
    memset(t95, 0, 8);
    t96 = 1U;
    t97 = t96;
    t98 = (t63 + 4);
    t99 = *((unsigned int *)t63);
    t96 = (t96 & t99);
    t100 = *((unsigned int *)t98);
    t97 = (t97 & t100);
    t101 = (t95 + 4);
    t102 = *((unsigned int *)t95);
    *((unsigned int *)t95) = (t102 | t96);
    t103 = *((unsigned int *)t101);
    *((unsigned int *)t101) = (t103 | t97);
    xsi_driver_vfirst_trans(t91, 0, 0);
    t104 = (t0 + 9216);
    *((int *)t104) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t22) = 1;
    goto LAB11;

LAB10:    t29 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB11;

LAB12:    t35 = (t0 + 6840);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = ((char*)((ng2)));
    memset(t39, 0, 8);
    t40 = (t37 + 4);
    t41 = (t38 + 4);
    t42 = *((unsigned int *)t37);
    t43 = *((unsigned int *)t38);
    t44 = (t42 ^ t43);
    t45 = *((unsigned int *)t40);
    t46 = *((unsigned int *)t41);
    t47 = (t45 ^ t46);
    t48 = (t44 | t47);
    t49 = *((unsigned int *)t40);
    t50 = *((unsigned int *)t41);
    t51 = (t49 | t50);
    t52 = (~(t51));
    t53 = (t48 & t52);
    if (t53 != 0)
        goto LAB18;

LAB15:    if (t51 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t39) = 1;

LAB18:    memset(t55, 0, 8);
    t56 = (t39 + 4);
    t57 = *((unsigned int *)t56);
    t58 = (~(t57));
    t59 = *((unsigned int *)t39);
    t60 = (t59 & t58);
    t61 = (t60 & 1U);
    if (t61 != 0)
        goto LAB19;

LAB20:    if (*((unsigned int *)t56) != 0)
        goto LAB21;

LAB22:    t64 = *((unsigned int *)t22);
    t65 = *((unsigned int *)t55);
    t66 = (t64 | t65);
    *((unsigned int *)t63) = t66;
    t67 = (t22 + 4);
    t68 = (t55 + 4);
    t69 = (t63 + 4);
    t70 = *((unsigned int *)t67);
    t71 = *((unsigned int *)t68);
    t72 = (t70 | t71);
    *((unsigned int *)t69) = t72;
    t73 = *((unsigned int *)t69);
    t74 = (t73 != 0);
    if (t74 == 1)
        goto LAB23;

LAB24:
LAB25:    goto LAB14;

LAB17:    t54 = (t39 + 4);
    *((unsigned int *)t39) = 1;
    *((unsigned int *)t54) = 1;
    goto LAB18;

LAB19:    *((unsigned int *)t55) = 1;
    goto LAB22;

LAB21:    t62 = (t55 + 4);
    *((unsigned int *)t55) = 1;
    *((unsigned int *)t62) = 1;
    goto LAB22;

LAB23:    t75 = *((unsigned int *)t63);
    t76 = *((unsigned int *)t69);
    *((unsigned int *)t63) = (t75 | t76);
    t77 = (t22 + 4);
    t78 = (t55 + 4);
    t79 = *((unsigned int *)t77);
    t80 = (~(t79));
    t81 = *((unsigned int *)t22);
    t82 = (t81 & t80);
    t83 = *((unsigned int *)t78);
    t84 = (~(t83));
    t85 = *((unsigned int *)t55);
    t86 = (t85 & t84);
    t87 = (~(t82));
    t88 = (~(t86));
    t89 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t89 & t87);
    t90 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t90 & t88);
    goto LAB25;

}

static void Cont_54_1(char *t0)
{
    char t6[8];
    char t22[8];
    char t39[8];
    char t55[8];
    char t63[8];
    char t91[8];
    char t108[8];
    char t124[8];
    char t132[8];
    char t160[8];
    char t177[8];
    char t193[8];
    char t201[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    char *t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    char *t98;
    char *t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    char *t104;
    char *t105;
    char *t106;
    char *t107;
    char *t109;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    char *t123;
    char *t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    char *t131;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t136;
    char *t137;
    char *t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    char *t146;
    char *t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    int t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    char *t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    char *t167;
    char *t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    char *t173;
    char *t174;
    char *t175;
    char *t176;
    char *t178;
    char *t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    char *t192;
    char *t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    char *t200;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    char *t205;
    char *t206;
    char *t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    char *t215;
    char *t216;
    unsigned int t217;
    unsigned int t218;
    unsigned int t219;
    int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    char *t229;
    char *t230;
    char *t231;
    char *t232;
    char *t233;
    unsigned int t234;
    unsigned int t235;
    char *t236;
    unsigned int t237;
    unsigned int t238;
    char *t239;
    unsigned int t240;
    unsigned int t241;
    char *t242;

LAB0:    t1 = (t0 + 8648U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 6840);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t22, 0, 8);
    t23 = (t6 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t6);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t23) != 0)
        goto LAB10;

LAB11:    t30 = (t22 + 4);
    t31 = *((unsigned int *)t22);
    t32 = (!(t31));
    t33 = *((unsigned int *)t30);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB12;

LAB13:    memcpy(t63, t22, 8);

LAB14:    memset(t91, 0, 8);
    t92 = (t63 + 4);
    t93 = *((unsigned int *)t92);
    t94 = (~(t93));
    t95 = *((unsigned int *)t63);
    t96 = (t95 & t94);
    t97 = (t96 & 1U);
    if (t97 != 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t92) != 0)
        goto LAB28;

LAB29:    t99 = (t91 + 4);
    t100 = *((unsigned int *)t91);
    t101 = (!(t100));
    t102 = *((unsigned int *)t99);
    t103 = (t101 || t102);
    if (t103 > 0)
        goto LAB30;

LAB31:    memcpy(t132, t91, 8);

LAB32:    memset(t160, 0, 8);
    t161 = (t132 + 4);
    t162 = *((unsigned int *)t161);
    t163 = (~(t162));
    t164 = *((unsigned int *)t132);
    t165 = (t164 & t163);
    t166 = (t165 & 1U);
    if (t166 != 0)
        goto LAB44;

LAB45:    if (*((unsigned int *)t161) != 0)
        goto LAB46;

LAB47:    t168 = (t160 + 4);
    t169 = *((unsigned int *)t160);
    t170 = (!(t169));
    t171 = *((unsigned int *)t168);
    t172 = (t170 || t171);
    if (t172 > 0)
        goto LAB48;

LAB49:    memcpy(t201, t160, 8);

LAB50:    t229 = (t0 + 9392);
    t230 = (t229 + 56U);
    t231 = *((char **)t230);
    t232 = (t231 + 56U);
    t233 = *((char **)t232);
    memset(t233, 0, 8);
    t234 = 1U;
    t235 = t234;
    t236 = (t201 + 4);
    t237 = *((unsigned int *)t201);
    t234 = (t234 & t237);
    t238 = *((unsigned int *)t236);
    t235 = (t235 & t238);
    t239 = (t233 + 4);
    t240 = *((unsigned int *)t233);
    *((unsigned int *)t233) = (t240 | t234);
    t241 = *((unsigned int *)t239);
    *((unsigned int *)t239) = (t241 | t235);
    xsi_driver_vfirst_trans(t229, 0, 0);
    t242 = (t0 + 9232);
    *((int *)t242) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t22) = 1;
    goto LAB11;

LAB10:    t29 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB11;

LAB12:    t35 = (t0 + 6840);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = ((char*)((ng4)));
    memset(t39, 0, 8);
    t40 = (t37 + 4);
    t41 = (t38 + 4);
    t42 = *((unsigned int *)t37);
    t43 = *((unsigned int *)t38);
    t44 = (t42 ^ t43);
    t45 = *((unsigned int *)t40);
    t46 = *((unsigned int *)t41);
    t47 = (t45 ^ t46);
    t48 = (t44 | t47);
    t49 = *((unsigned int *)t40);
    t50 = *((unsigned int *)t41);
    t51 = (t49 | t50);
    t52 = (~(t51));
    t53 = (t48 & t52);
    if (t53 != 0)
        goto LAB18;

LAB15:    if (t51 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t39) = 1;

LAB18:    memset(t55, 0, 8);
    t56 = (t39 + 4);
    t57 = *((unsigned int *)t56);
    t58 = (~(t57));
    t59 = *((unsigned int *)t39);
    t60 = (t59 & t58);
    t61 = (t60 & 1U);
    if (t61 != 0)
        goto LAB19;

LAB20:    if (*((unsigned int *)t56) != 0)
        goto LAB21;

LAB22:    t64 = *((unsigned int *)t22);
    t65 = *((unsigned int *)t55);
    t66 = (t64 | t65);
    *((unsigned int *)t63) = t66;
    t67 = (t22 + 4);
    t68 = (t55 + 4);
    t69 = (t63 + 4);
    t70 = *((unsigned int *)t67);
    t71 = *((unsigned int *)t68);
    t72 = (t70 | t71);
    *((unsigned int *)t69) = t72;
    t73 = *((unsigned int *)t69);
    t74 = (t73 != 0);
    if (t74 == 1)
        goto LAB23;

LAB24:
LAB25:    goto LAB14;

LAB17:    t54 = (t39 + 4);
    *((unsigned int *)t39) = 1;
    *((unsigned int *)t54) = 1;
    goto LAB18;

LAB19:    *((unsigned int *)t55) = 1;
    goto LAB22;

LAB21:    t62 = (t55 + 4);
    *((unsigned int *)t55) = 1;
    *((unsigned int *)t62) = 1;
    goto LAB22;

LAB23:    t75 = *((unsigned int *)t63);
    t76 = *((unsigned int *)t69);
    *((unsigned int *)t63) = (t75 | t76);
    t77 = (t22 + 4);
    t78 = (t55 + 4);
    t79 = *((unsigned int *)t77);
    t80 = (~(t79));
    t81 = *((unsigned int *)t22);
    t82 = (t81 & t80);
    t83 = *((unsigned int *)t78);
    t84 = (~(t83));
    t85 = *((unsigned int *)t55);
    t86 = (t85 & t84);
    t87 = (~(t82));
    t88 = (~(t86));
    t89 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t89 & t87);
    t90 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t90 & t88);
    goto LAB25;

LAB26:    *((unsigned int *)t91) = 1;
    goto LAB29;

LAB28:    t98 = (t91 + 4);
    *((unsigned int *)t91) = 1;
    *((unsigned int *)t98) = 1;
    goto LAB29;

LAB30:    t104 = (t0 + 6840);
    t105 = (t104 + 56U);
    t106 = *((char **)t105);
    t107 = ((char*)((ng5)));
    memset(t108, 0, 8);
    t109 = (t106 + 4);
    t110 = (t107 + 4);
    t111 = *((unsigned int *)t106);
    t112 = *((unsigned int *)t107);
    t113 = (t111 ^ t112);
    t114 = *((unsigned int *)t109);
    t115 = *((unsigned int *)t110);
    t116 = (t114 ^ t115);
    t117 = (t113 | t116);
    t118 = *((unsigned int *)t109);
    t119 = *((unsigned int *)t110);
    t120 = (t118 | t119);
    t121 = (~(t120));
    t122 = (t117 & t121);
    if (t122 != 0)
        goto LAB36;

LAB33:    if (t120 != 0)
        goto LAB35;

LAB34:    *((unsigned int *)t108) = 1;

LAB36:    memset(t124, 0, 8);
    t125 = (t108 + 4);
    t126 = *((unsigned int *)t125);
    t127 = (~(t126));
    t128 = *((unsigned int *)t108);
    t129 = (t128 & t127);
    t130 = (t129 & 1U);
    if (t130 != 0)
        goto LAB37;

LAB38:    if (*((unsigned int *)t125) != 0)
        goto LAB39;

LAB40:    t133 = *((unsigned int *)t91);
    t134 = *((unsigned int *)t124);
    t135 = (t133 | t134);
    *((unsigned int *)t132) = t135;
    t136 = (t91 + 4);
    t137 = (t124 + 4);
    t138 = (t132 + 4);
    t139 = *((unsigned int *)t136);
    t140 = *((unsigned int *)t137);
    t141 = (t139 | t140);
    *((unsigned int *)t138) = t141;
    t142 = *((unsigned int *)t138);
    t143 = (t142 != 0);
    if (t143 == 1)
        goto LAB41;

LAB42:
LAB43:    goto LAB32;

LAB35:    t123 = (t108 + 4);
    *((unsigned int *)t108) = 1;
    *((unsigned int *)t123) = 1;
    goto LAB36;

LAB37:    *((unsigned int *)t124) = 1;
    goto LAB40;

LAB39:    t131 = (t124 + 4);
    *((unsigned int *)t124) = 1;
    *((unsigned int *)t131) = 1;
    goto LAB40;

LAB41:    t144 = *((unsigned int *)t132);
    t145 = *((unsigned int *)t138);
    *((unsigned int *)t132) = (t144 | t145);
    t146 = (t91 + 4);
    t147 = (t124 + 4);
    t148 = *((unsigned int *)t146);
    t149 = (~(t148));
    t150 = *((unsigned int *)t91);
    t151 = (t150 & t149);
    t152 = *((unsigned int *)t147);
    t153 = (~(t152));
    t154 = *((unsigned int *)t124);
    t155 = (t154 & t153);
    t156 = (~(t151));
    t157 = (~(t155));
    t158 = *((unsigned int *)t138);
    *((unsigned int *)t138) = (t158 & t156);
    t159 = *((unsigned int *)t138);
    *((unsigned int *)t138) = (t159 & t157);
    goto LAB43;

LAB44:    *((unsigned int *)t160) = 1;
    goto LAB47;

LAB46:    t167 = (t160 + 4);
    *((unsigned int *)t160) = 1;
    *((unsigned int *)t167) = 1;
    goto LAB47;

LAB48:    t173 = (t0 + 6840);
    t174 = (t173 + 56U);
    t175 = *((char **)t174);
    t176 = ((char*)((ng6)));
    memset(t177, 0, 8);
    t178 = (t175 + 4);
    t179 = (t176 + 4);
    t180 = *((unsigned int *)t175);
    t181 = *((unsigned int *)t176);
    t182 = (t180 ^ t181);
    t183 = *((unsigned int *)t178);
    t184 = *((unsigned int *)t179);
    t185 = (t183 ^ t184);
    t186 = (t182 | t185);
    t187 = *((unsigned int *)t178);
    t188 = *((unsigned int *)t179);
    t189 = (t187 | t188);
    t190 = (~(t189));
    t191 = (t186 & t190);
    if (t191 != 0)
        goto LAB54;

LAB51:    if (t189 != 0)
        goto LAB53;

LAB52:    *((unsigned int *)t177) = 1;

LAB54:    memset(t193, 0, 8);
    t194 = (t177 + 4);
    t195 = *((unsigned int *)t194);
    t196 = (~(t195));
    t197 = *((unsigned int *)t177);
    t198 = (t197 & t196);
    t199 = (t198 & 1U);
    if (t199 != 0)
        goto LAB55;

LAB56:    if (*((unsigned int *)t194) != 0)
        goto LAB57;

LAB58:    t202 = *((unsigned int *)t160);
    t203 = *((unsigned int *)t193);
    t204 = (t202 | t203);
    *((unsigned int *)t201) = t204;
    t205 = (t160 + 4);
    t206 = (t193 + 4);
    t207 = (t201 + 4);
    t208 = *((unsigned int *)t205);
    t209 = *((unsigned int *)t206);
    t210 = (t208 | t209);
    *((unsigned int *)t207) = t210;
    t211 = *((unsigned int *)t207);
    t212 = (t211 != 0);
    if (t212 == 1)
        goto LAB59;

LAB60:
LAB61:    goto LAB50;

LAB53:    t192 = (t177 + 4);
    *((unsigned int *)t177) = 1;
    *((unsigned int *)t192) = 1;
    goto LAB54;

LAB55:    *((unsigned int *)t193) = 1;
    goto LAB58;

LAB57:    t200 = (t193 + 4);
    *((unsigned int *)t193) = 1;
    *((unsigned int *)t200) = 1;
    goto LAB58;

LAB59:    t213 = *((unsigned int *)t201);
    t214 = *((unsigned int *)t207);
    *((unsigned int *)t201) = (t213 | t214);
    t215 = (t160 + 4);
    t216 = (t193 + 4);
    t217 = *((unsigned int *)t215);
    t218 = (~(t217));
    t219 = *((unsigned int *)t160);
    t220 = (t219 & t218);
    t221 = *((unsigned int *)t216);
    t222 = (~(t221));
    t223 = *((unsigned int *)t193);
    t224 = (t223 & t222);
    t225 = (~(t220));
    t226 = (~(t224));
    t227 = *((unsigned int *)t207);
    *((unsigned int *)t207) = (t227 & t225);
    t228 = *((unsigned int *)t207);
    *((unsigned int *)t207) = (t228 & t226);
    goto LAB61;

}

static void Always_58_2(char *t0)
{
    char t14[8];
    char t15[8];
    char t16[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    int t13;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    char *t23;
    unsigned int t24;
    int t25;
    int t26;
    char *t27;
    unsigned int t28;
    int t29;
    int t30;
    unsigned int t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    int t35;
    int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;

LAB0:    t1 = (t0 + 8896U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(58, ng0);
    t2 = (t0 + 9248);
    *((int *)t2) = 1;
    t3 = (t0 + 8928);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(59, ng0);

LAB5:    xsi_set_current_line(60, ng0);
    t4 = (t0 + 5000U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(73, ng0);

LAB10:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 6840);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);

LAB11:    t5 = ((char*)((ng7)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t5, 5);
    if (t13 == 1)
        goto LAB12;

LAB13:    t2 = ((char*)((ng1)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB14;

LAB15:    t2 = ((char*)((ng9)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng11)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng12)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB20;

LAB21:    t2 = ((char*)((ng13)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB22;

LAB23:    t2 = ((char*)((ng14)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB24;

LAB25:    t2 = ((char*)((ng2)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB26;

LAB27:    t2 = ((char*)((ng16)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB28;

LAB29:    t2 = ((char*)((ng19)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB30;

LAB31:    t2 = ((char*)((ng21)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB32;

LAB33:    t2 = ((char*)((ng3)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB34;

LAB35:    t2 = ((char*)((ng23)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB36;

LAB37:    t2 = ((char*)((ng24)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB38;

LAB39:    t2 = ((char*)((ng27)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB40;

LAB41:    t2 = ((char*)((ng30)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB42;

LAB43:    t2 = ((char*)((ng4)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB44;

LAB45:    t2 = ((char*)((ng5)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB46;

LAB47:    t2 = ((char*)((ng6)));
    t13 = xsi_vlog_unsigned_case_compare(t4, 5, t2, 5);
    if (t13 == 1)
        goto LAB48;

LAB49:
LAB51:
LAB50:    xsi_set_current_line(254, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB52:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(61, ng0);

LAB9:    xsi_set_current_line(62, ng0);
    t11 = ((char*)((ng7)));
    t12 = (t0 + 6680);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 4);
    xsi_set_current_line(63, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 5560);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(65, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 5720);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 6, 0LL);
    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6200);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(67, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 5880);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 7, 0LL);
    xsi_set_current_line(68, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6040);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6360);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(70, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6520);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    goto LAB8;

LAB12:    xsi_set_current_line(76, ng0);

LAB53:    xsi_set_current_line(77, ng0);
    t11 = ((char*)((ng7)));
    t12 = (t0 + 6680);
    xsi_vlogvar_assign_value(t12, t11, 0, 0, 4);
    xsi_set_current_line(78, ng0);
    t2 = (t0 + 4200U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB54;

LAB55:    xsi_set_current_line(88, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB56:    goto LAB52;

LAB14:    xsi_set_current_line(91, ng0);

LAB58:    xsi_set_current_line(93, ng0);
    t3 = ((char*)((ng9)));
    t5 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 5, 0LL);
    xsi_set_current_line(94, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 6680);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    goto LAB52;

LAB16:    xsi_set_current_line(97, ng0);

LAB59:    xsi_set_current_line(98, ng0);
    t3 = (t0 + 4360U);
    t5 = *((char **)t3);
    t3 = (t5 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB60;

LAB61:    xsi_set_current_line(105, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB62:    goto LAB52;

LAB18:    xsi_set_current_line(108, ng0);

LAB64:    xsi_set_current_line(109, ng0);
    t3 = ((char*)((ng12)));
    t5 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 5, 0LL);
    goto LAB52;

LAB20:    xsi_set_current_line(112, ng0);

LAB65:    xsi_set_current_line(113, ng0);
    t3 = ((char*)((ng12)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(114, ng0);
    t2 = (t0 + 4360U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB66;

LAB67:    xsi_set_current_line(120, ng0);
    t2 = ((char*)((ng12)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB68:    goto LAB52;

LAB22:    xsi_set_current_line(123, ng0);

LAB70:    xsi_set_current_line(124, ng0);
    t3 = ((char*)((ng13)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(125, ng0);
    t2 = (t0 + 4200U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB71;

LAB72:    xsi_set_current_line(128, ng0);
    t2 = ((char*)((ng13)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB73:    goto LAB52;

LAB24:    xsi_set_current_line(131, ng0);

LAB74:    xsi_set_current_line(132, ng0);
    t3 = ((char*)((ng14)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(133, ng0);
    t2 = (t0 + 4200U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB75;

LAB76:    xsi_set_current_line(142, ng0);
    t2 = ((char*)((ng14)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB77:    goto LAB52;

LAB26:    xsi_set_current_line(145, ng0);

LAB79:    xsi_set_current_line(147, ng0);
    t3 = ((char*)((ng2)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(148, ng0);
    t2 = ((char*)((ng16)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB52;

LAB28:    xsi_set_current_line(151, ng0);

LAB80:    xsi_set_current_line(152, ng0);
    t3 = ((char*)((ng16)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(153, ng0);
    t2 = (t0 + 4360U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB81;

LAB82:    xsi_set_current_line(159, ng0);
    t2 = ((char*)((ng16)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB83:    goto LAB52;

LAB30:    xsi_set_current_line(162, ng0);

LAB87:    xsi_set_current_line(163, ng0);
    t3 = ((char*)((ng19)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(164, ng0);
    t2 = (t0 + 4360U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB88;

LAB89:    xsi_set_current_line(170, ng0);
    t2 = ((char*)((ng19)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB90:    goto LAB52;

LAB32:    xsi_set_current_line(173, ng0);

LAB94:    xsi_set_current_line(174, ng0);
    t3 = ((char*)((ng21)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(175, ng0);
    t2 = (t0 + 7000);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memset(t14, 0, 8);
    t11 = (t14 + 4);
    t12 = (t5 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (t6 >> 12);
    t8 = (t7 & 1);
    *((unsigned int *)t14) = t8;
    t9 = *((unsigned int *)t12);
    t10 = (t9 >> 12);
    t22 = (t10 & 1);
    *((unsigned int *)t11) = t22;
    t17 = (t14 + 4);
    t24 = *((unsigned int *)t17);
    t28 = (~(t24));
    t31 = *((unsigned int *)t14);
    t33 = (t31 & t28);
    t34 = (t33 != 0);
    if (t34 > 0)
        goto LAB95;

LAB96:    xsi_set_current_line(181, ng0);

LAB99:    xsi_set_current_line(182, ng0);
    t2 = (t0 + 7000);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memset(t14, 0, 8);
    t11 = (t14 + 4);
    t12 = (t5 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (t6 >> 4);
    *((unsigned int *)t14) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 4);
    *((unsigned int *)t11) = t9;
    t10 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t10 & 255U);
    t22 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t22 & 255U);
    t17 = (t0 + 7160);
    xsi_vlogvar_wait_assign_value(t17, t14, 0, 0, 8, 0LL);
    xsi_set_current_line(183, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB97:    goto LAB52;

LAB34:    xsi_set_current_line(187, ng0);

LAB100:    xsi_set_current_line(188, ng0);
    t3 = ((char*)((ng3)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(189, ng0);
    t2 = (t0 + 4200U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB101;

LAB102:    xsi_set_current_line(194, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB103:    goto LAB52;

LAB36:    xsi_set_current_line(197, ng0);

LAB105:    xsi_set_current_line(198, ng0);
    t3 = ((char*)((ng23)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(199, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 7320);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    xsi_set_current_line(200, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 7480);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    xsi_set_current_line(201, ng0);
    t2 = ((char*)((ng24)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB52;

LAB38:    xsi_set_current_line(204, ng0);

LAB106:    xsi_set_current_line(205, ng0);
    t3 = ((char*)((ng24)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(206, ng0);
    t2 = (t0 + 7160);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t11 = ((char*)((ng25)));
    memset(t14, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB108;

LAB107:    t17 = (t11 + 4);
    if (*((unsigned int *)t17) != 0)
        goto LAB108;

LAB111:    if (*((unsigned int *)t5) > *((unsigned int *)t11))
        goto LAB109;

LAB110:    t19 = (t14 + 4);
    t6 = *((unsigned int *)t19);
    t7 = (~(t6));
    t8 = *((unsigned int *)t14);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB112;

LAB113:    xsi_set_current_line(213, ng0);
    t2 = ((char*)((ng27)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB114:    goto LAB52;

LAB40:    xsi_set_current_line(216, ng0);

LAB116:    xsi_set_current_line(217, ng0);
    t3 = ((char*)((ng27)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(218, ng0);
    t2 = (t0 + 7160);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t11 = ((char*)((ng28)));
    memset(t14, 0, 8);
    t12 = (t5 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB118;

LAB117:    t17 = (t11 + 4);
    if (*((unsigned int *)t17) != 0)
        goto LAB118;

LAB121:    if (*((unsigned int *)t5) > *((unsigned int *)t11))
        goto LAB119;

LAB120:    t19 = (t14 + 4);
    t6 = *((unsigned int *)t19);
    t7 = (~(t6));
    t8 = *((unsigned int *)t14);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB122;

LAB123:    xsi_set_current_line(225, ng0);
    t2 = ((char*)((ng30)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);

LAB124:    goto LAB52;

LAB42:    xsi_set_current_line(228, ng0);

LAB126:    xsi_set_current_line(229, ng0);
    t3 = ((char*)((ng30)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(230, ng0);
    t2 = (t0 + 7480);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t11 = ((char*)((ng11)));
    xsi_vlogtype_concat(t14, 8, 8, 2U, t11, 4, t5, 4);
    t12 = (t0 + 6520);
    xsi_vlogvar_wait_assign_value(t12, t14, 0, 0, 8, 0LL);
    xsi_set_current_line(231, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 6360);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(232, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB52;

LAB44:    xsi_set_current_line(235, ng0);

LAB127:    xsi_set_current_line(236, ng0);
    t3 = ((char*)((ng30)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(237, ng0);
    t2 = (t0 + 7320);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t11 = ((char*)((ng11)));
    xsi_vlogtype_concat(t14, 8, 8, 2U, t11, 4, t5, 4);
    t12 = (t0 + 6520);
    xsi_vlogvar_wait_assign_value(t12, t14, 0, 0, 8, 0LL);
    xsi_set_current_line(238, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 6360);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(239, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB52;

LAB46:    xsi_set_current_line(242, ng0);

LAB128:    xsi_set_current_line(243, ng0);
    t3 = ((char*)((ng30)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(244, ng0);
    t2 = (t0 + 7160);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    memset(t15, 0, 8);
    t11 = (t15 + 4);
    t12 = (t5 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (t6 >> 0);
    *((unsigned int *)t15) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 0);
    *((unsigned int *)t11) = t9;
    t10 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t10 & 15U);
    t22 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t22 & 15U);
    t17 = ((char*)((ng11)));
    xsi_vlogtype_concat(t14, 8, 8, 2U, t17, 4, t15, 4);
    t18 = (t0 + 6520);
    xsi_vlogvar_wait_assign_value(t18, t14, 0, 0, 8, 0LL);
    xsi_set_current_line(245, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 6360);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(246, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB52;

LAB48:    xsi_set_current_line(249, ng0);

LAB129:    xsi_set_current_line(250, ng0);
    t3 = ((char*)((ng30)));
    t5 = (t0 + 6680);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 4);
    xsi_set_current_line(251, ng0);
    t2 = ((char*)((ng13)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB52;

LAB54:    xsi_set_current_line(79, ng0);

LAB57:    xsi_set_current_line(80, ng0);
    t5 = ((char*)((ng8)));
    t11 = (t0 + 5560);
    xsi_vlogvar_wait_assign_value(t11, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(81, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 5720);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 6, 0LL);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 3056);
    t3 = *((char **)t2);
    t2 = (t0 + 6200);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 8, 0LL);
    xsi_set_current_line(83, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 5880);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 7, 0LL);
    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(85, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 6680);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    goto LAB56;

LAB60:    xsi_set_current_line(99, ng0);

LAB63:    xsi_set_current_line(100, ng0);
    t11 = (t0 + 3192);
    t12 = *((char **)t11);
    t11 = (t0 + 6040);
    xsi_vlogvar_wait_assign_value(t11, t12, 0, 0, 8, 0LL);
    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng11)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    xsi_set_current_line(102, ng0);
    t2 = ((char*)((ng11)));
    t3 = (t0 + 6680);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    goto LAB62;

LAB66:    xsi_set_current_line(115, ng0);

LAB69:    xsi_set_current_line(116, ng0);
    t5 = (t0 + 3328);
    t11 = *((char **)t5);
    t5 = (t0 + 6040);
    xsi_vlogvar_wait_assign_value(t5, t11, 0, 0, 8, 0LL);
    xsi_set_current_line(117, ng0);
    t2 = ((char*)((ng13)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB68;

LAB71:    xsi_set_current_line(126, ng0);
    t5 = ((char*)((ng14)));
    t11 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t11, t5, 0, 0, 5, 0LL);
    goto LAB73;

LAB75:    xsi_set_current_line(134, ng0);

LAB78:    xsi_set_current_line(135, ng0);
    t5 = ((char*)((ng15)));
    t11 = (t0 + 5560);
    xsi_vlogvar_wait_assign_value(t11, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(136, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 5720);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 6, 0LL);
    xsi_set_current_line(137, ng0);
    t2 = ((char*)((ng13)));
    t3 = (t0 + 6200);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 8, 0LL);
    xsi_set_current_line(138, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 5880);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 7, 0LL);
    xsi_set_current_line(139, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB77;

LAB81:    xsi_set_current_line(154, ng0);

LAB84:    xsi_set_current_line(155, ng0);
    t5 = (t0 + 4520U);
    t11 = *((char **)t5);
    t5 = (t0 + 7000);
    t12 = (t0 + 7000);
    t17 = (t12 + 72U);
    t18 = *((char **)t17);
    t19 = ((char*)((ng17)));
    t20 = ((char*)((ng18)));
    xsi_vlog_convert_partindices(t14, t15, t16, ((int*)(t18)), 2, t19, 32, 1, t20, 32, 1);
    t21 = (t14 + 4);
    t22 = *((unsigned int *)t21);
    t13 = (!(t22));
    t23 = (t15 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (!(t24));
    t26 = (t13 && t25);
    t27 = (t16 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (!(t28));
    t30 = (t26 && t29);
    if (t30 == 1)
        goto LAB85;

LAB86:    xsi_set_current_line(156, ng0);
    t2 = ((char*)((ng19)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB83;

LAB85:    t31 = *((unsigned int *)t16);
    t32 = (t31 + 0);
    t33 = *((unsigned int *)t14);
    t34 = *((unsigned int *)t15);
    t35 = (t33 - t34);
    t36 = (t35 + 1);
    xsi_vlogvar_wait_assign_value(t5, t11, t32, *((unsigned int *)t15), t36, 0LL);
    goto LAB86;

LAB88:    xsi_set_current_line(165, ng0);

LAB91:    xsi_set_current_line(166, ng0);
    t5 = (t0 + 4520U);
    t11 = *((char **)t5);
    t5 = (t0 + 7000);
    t12 = (t0 + 7000);
    t17 = (t12 + 72U);
    t18 = *((char **)t17);
    t19 = ((char*)((ng20)));
    t20 = ((char*)((ng8)));
    xsi_vlog_convert_partindices(t14, t15, t16, ((int*)(t18)), 2, t19, 32, 1, t20, 32, 1);
    t21 = (t14 + 4);
    t22 = *((unsigned int *)t21);
    t13 = (!(t22));
    t23 = (t15 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (!(t24));
    t26 = (t13 && t25);
    t27 = (t16 + 4);
    t28 = *((unsigned int *)t27);
    t29 = (!(t28));
    t30 = (t26 && t29);
    if (t30 == 1)
        goto LAB92;

LAB93:    xsi_set_current_line(167, ng0);
    t2 = ((char*)((ng21)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB90;

LAB92:    t31 = *((unsigned int *)t16);
    t32 = (t31 + 0);
    t33 = *((unsigned int *)t14);
    t34 = *((unsigned int *)t15);
    t35 = (t33 - t34);
    t36 = (t35 + 1);
    xsi_vlogvar_wait_assign_value(t5, t11, t32, *((unsigned int *)t15), t36, 0LL);
    goto LAB93;

LAB95:    xsi_set_current_line(176, ng0);

LAB98:    xsi_set_current_line(177, ng0);
    t18 = ((char*)((ng22)));
    t19 = (t0 + 7000);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    memset(t15, 0, 8);
    t23 = (t15 + 4);
    t27 = (t21 + 4);
    t37 = *((unsigned int *)t21);
    t38 = (t37 >> 4);
    *((unsigned int *)t15) = t38;
    t39 = *((unsigned int *)t27);
    t40 = (t39 >> 4);
    *((unsigned int *)t23) = t40;
    t41 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t41 & 255U);
    t42 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t42 & 255U);
    memset(t16, 0, 8);
    xsi_vlog_unsigned_minus(t16, 32, t18, 32, t15, 32);
    t43 = (t0 + 7160);
    xsi_vlogvar_wait_assign_value(t43, t16, 0, 0, 8, 0LL);
    xsi_set_current_line(178, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB97;

LAB101:    xsi_set_current_line(190, ng0);

LAB104:    xsi_set_current_line(191, ng0);
    t5 = ((char*)((ng23)));
    t11 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t11, t5, 0, 0, 5, 0LL);
    goto LAB103;

LAB108:    t18 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB110;

LAB109:    *((unsigned int *)t14) = 1;
    goto LAB110;

LAB112:    xsi_set_current_line(207, ng0);

LAB115:    xsi_set_current_line(208, ng0);
    t20 = (t0 + 7480);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    t27 = ((char*)((ng15)));
    memset(t15, 0, 8);
    xsi_vlog_unsigned_add(t15, 32, t23, 4, t27, 32);
    t43 = (t0 + 7480);
    xsi_vlogvar_wait_assign_value(t43, t15, 0, 0, 4, 0LL);
    xsi_set_current_line(209, ng0);
    t2 = (t0 + 7160);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t11 = ((char*)((ng26)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_minus(t14, 32, t5, 8, t11, 32);
    t12 = (t0 + 7160);
    xsi_vlogvar_wait_assign_value(t12, t14, 0, 0, 8, 0LL);
    xsi_set_current_line(210, ng0);
    t2 = ((char*)((ng24)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB114;

LAB118:    t18 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB120;

LAB119:    *((unsigned int *)t14) = 1;
    goto LAB120;

LAB122:    xsi_set_current_line(219, ng0);

LAB125:    xsi_set_current_line(220, ng0);
    t20 = (t0 + 7320);
    t21 = (t20 + 56U);
    t23 = *((char **)t21);
    t27 = ((char*)((ng15)));
    memset(t15, 0, 8);
    xsi_vlog_unsigned_add(t15, 32, t23, 4, t27, 32);
    t43 = (t0 + 7320);
    xsi_vlogvar_wait_assign_value(t43, t15, 0, 0, 4, 0LL);
    xsi_set_current_line(221, ng0);
    t2 = (t0 + 7160);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t11 = ((char*)((ng29)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_minus(t14, 32, t5, 8, t11, 32);
    t12 = (t0 + 7160);
    xsi_vlogvar_wait_assign_value(t12, t14, 0, 0, 8, 0LL);
    xsi_set_current_line(222, ng0);
    t2 = ((char*)((ng27)));
    t3 = (t0 + 6840);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    goto LAB124;

}


extern void work_m_00000000001325241487_4144471541_init()
{
	static char *pe[] = {(void *)Cont_53_0,(void *)Cont_54_1,(void *)Always_58_2};
	xsi_register_didat("work_m_00000000001325241487_4144471541", "isim/system_test_isim_beh.exe.sim/work/m_00000000001325241487_4144471541.didat");
	xsi_register_executes(pe);
}
